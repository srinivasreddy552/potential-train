package com.check24.SearchActions.check24searchActionsservice;

import static org.junit.Assert.assertEquals;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.check24.SearchActions.check24searchActionsservice.model.Bid;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SearchActionsControllerTest {

	@Autowired
	private AuctionsService auctionsService;

	@Test
	public void test() {

		List<Bid> listofBids = auctionsService.initiateDummyBids(5);

		List<Bid> sortedBidsBasedonRank = listofBids.stream().sorted(Comparator.comparingDouble(Bid::getBidValue))
				.collect(Collectors.toList());

		assertEquals(24, sortedBidsBasedonRank.get(0).getBidValue(), 0);
	}

}

package com.check24.SearchActions.check24searchActionsservice;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Check24SearchActionsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

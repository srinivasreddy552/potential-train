package com.check24.SearchActions.check24searchActionsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Check24SearchActionsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Check24SearchActionsServiceApplication.class, args);
	}

}

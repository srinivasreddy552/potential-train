package com.check24.SearchActions.check24searchActionsservice;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.check24.SearchActions.check24searchActionsservice.model.Bid;

@RestController
public class SearchActionsController {

	@Autowired
	private AuctionsService auctionsService;
	Logger LOGGER = LoggerFactory.getLogger(SearchActionsController.class);

	@GetMapping("/auction/bidByRank/{dummySearchString}/")
	public List<Bid> allocateSlotBasedonBidbyRank(String dummySearchString) {

		List<Bid> listofBids = auctionsService.initiateDummyBids(5);

		List<Bid> sortedBidsBasedonRank = listofBids.stream().sorted(Comparator.comparingDouble(Bid::getBidValue))
				.collect(Collectors.toList());

		sortedBidsBasedonRank.forEach(System.out::println);

		return sortedBidsBasedonRank;

	}

}

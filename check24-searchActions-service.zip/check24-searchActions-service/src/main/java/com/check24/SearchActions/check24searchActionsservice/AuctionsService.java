package com.check24.SearchActions.check24searchActionsservice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.check24.SearchActions.check24searchActionsservice.model.Bid;

@Service
public class AuctionsService {

	public List<Bid> initiateDummyBids(int count) {

		List<Bid> resl = new ArrayList<Bid>();
		for (int i = 0; i <= count; i++) {

			Bid a1 = new Bid();

			a1.setBidTitle("DummyBidName" + i);
			a1.setBidDescription("Dummy Bid description" + i);
			a1.setCtrValue("CTR value ---" + i);
			a1.setAgentName("Dummy agent name---" + i);
			resl.add(a1);
		}
		return resl;
	}

}

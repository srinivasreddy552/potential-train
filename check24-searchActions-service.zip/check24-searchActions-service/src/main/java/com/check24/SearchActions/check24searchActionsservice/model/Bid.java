package com.check24.SearchActions.check24searchActionsservice.model;

public class Bid {

	public Bid() {

	}

	private String bidTitle;

	private String bidDescription;

	private String bidName;

	private String budWeight;

	private String ctrValue;

	private String agentName;

	private double bidValue;

	public String getBidTitle() {
		return bidTitle;
	}

	public void setBidTitle(String bidTitle) {
		this.bidTitle = bidTitle;
	}

	public double getBidValue() {
		return bidValue;
	}

	public void setBidValue(double bidValue) {
		this.bidValue = bidValue;
	}

	public String getBidDescription() {
		return bidDescription;
	}

	public void setBidDescription(String bidDescription) {
		this.bidDescription = bidDescription;
	}

	public String getBidName() {
		return bidName;
	}

	public void setBidName(String bidName) {
		this.bidName = bidName;
	}

	public String getBudWeight() {
		return budWeight;
	}

	public void setBudWeight(String budWeight) {
		this.budWeight = budWeight;
	}

	public String getCtrValue() {
		return ctrValue;
	}

	public void setCtrValue(String ctrValue) {
		this.ctrValue = ctrValue;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	@Override
	public String toString() {
		return "Auctions [bidTitle=" + bidTitle + ", bidDescription=" + bidDescription + ", bidName=" + bidName
				+ ", budWeight=" + budWeight + ", ctrValue=" + ctrValue + "]";
	}

}
